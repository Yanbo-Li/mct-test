/********************************************************************************
** Form generated from reading UI file 'newform.ui'
**
** Created by: Qt User Interface Compiler version 5.9.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWFORM_H
#define UI_NEWFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_newform
{
public:

    void setupUi(QWidget *newform)
    {
        if (newform->objectName().isEmpty())
            newform->setObjectName(QStringLiteral("newform"));
        newform->resize(400, 300);

        retranslateUi(newform);

        QMetaObject::connectSlotsByName(newform);
    } // setupUi

    void retranslateUi(QWidget *newform)
    {
        newform->setWindowTitle(QApplication::translate("newform", "Form", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class newform: public Ui_newform {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWFORM_H
