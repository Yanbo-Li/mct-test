#include "controlsystemwindow.h"
#include "ui_controlsystemwindow.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <QVector>

using namespace std;

ControlSystemWindow::ControlSystemWindow(MathEngine* me, WolframLink * link) :
    ui(new Ui::ControlSystemWindow)
{
    this->me = me;
    this->link = link;
    ui->setupUi(this);
    phaseplotted = false;
    magnitudeplotted = false;

    ui->phasePlot->xAxis->setLabel("Frequency(rad/s)");
    ui->phasePlot->yAxis->setLabel("Phase(deg)");
    ui->magnitudePlot->yAxis->setLabel("Magnitude(dB)");

    connect(ui->phasePlot, SIGNAL(selectionChangedByUser()),this,SLOT(getClickedPoint()));
    connect(ui->magnitudePlot, SIGNAL(selectionChangedByUser()),this,SLOT(getClickedPoint()));
}



void ControlSystemWindow::on_plotButton_clicked()
{
    //Plot the Phase of Bodeplot
    Plot P = link->getPhase();

    std::string line;

    QVector<double> colum1; //defined as ...static to avoid over-writing
    QVector<double> colum2;

    colum1 = QVector<double>::fromStdVector(P.x);
    colum2 = QVector<double>::fromStdVector(P.y);

    //Plot the Magnitude of Bodeplot
    Plot Q = link->getFreq();

    QVector<double> colum3; //defined as ...static to avoid over-writing
    QVector<double> colum4;

    colum3 = QVector<double>::fromStdVector(Q.x);
    colum4 = QVector<double>::fromStdVector(Q.y);

    if (phaseplotted == false)
    {
        ui->phasePlot->addGraph();
        ui->phasePlot->graph(0)->setData(colum1, colum2);
        //ui->phasePlot->xAxis->setLabel("Frequency(rad/sec)");
        //ui->phasePlot->yAxis->setLabel("Phase(deg)");

        //set subgrid visible
        //ui->phasePlot->xAxis->grid()->setSubGridVisible(true);
        //ui->phasePlot->yAxis->grid()->setSubGridVisible(true);

        //find the limits for x and y values, set axes ranges, so we see all data

        //set the maximum range of x to [0.01,100]


        ui->phasePlot->xAxis->setScaleType(QCPAxis::stLogarithmic);
        QSharedPointer<QCPAxisTickerLog> logTicker(new QCPAxisTickerLog);
        ui->phasePlot->xAxis->setTicker(logTicker);
        ui->phasePlot->xAxis->setNumberFormat("eb"); // e = exponential, b = beautiful decimal powers
        ui->phasePlot->xAxis->setNumberPrecision(0); // makes sure "1*10^4" is displayed only as "10^4"

        //QSharedPointer<QCPAxisTickerFixed> fixedTicker(new QCPAxisTickerFixed);
        //ui->phasePlot->yAxis->setTicker(fixedTicker);
        //fixedTicker->setTickStep(45);
        ui->phasePlot->yAxis->setSubTicks(false);

        ui->phasePlot->rescaleAxes(true); // plot visible points
        ui->phasePlot->xAxis->setRange(0.01, 100);
        ui->phasePlot->replot();
        phaseplotted = true;
        //ui->phasePlot->yAxis->setRange(yMin, yMax);

        ui->magnitudePlot->addGraph();
        ui->magnitudePlot->graph(0)->setData(colum3, colum4);

        ui->magnitudePlot->xAxis->setScaleType(QCPAxis::stLogarithmic);
        //QSharedPointer<QCPAxisTickerLog> logTicker(new QCPAxisTickerLog);
        ui->magnitudePlot->xAxis->setTicker(logTicker);
        ui->magnitudePlot->xAxis->setNumberFormat("eb"); // e = exponential, b = beautiful decimal powers
        ui->magnitudePlot->xAxis->setNumberPrecision(0); // makes sure "1*10^4" is displayed only as "10^4"

        //QSharedPointer<QCPAxisTickerFixed> fixedTicker(new QCPAxisTickerFixed);
        //ui->magnitudePlot->yAxis->setTicker(fixedTicker);
        //fixedTicker->setTickStep(20);
        ui->magnitudePlot->yAxis->setSubTicks(false);

        ui->magnitudePlot->rescaleAxes(true); // plot visible points
        ui->magnitudePlot->xAxis->setRange(0.01, 100);

        ui->magnitudePlot->replot();


        magnitudeplotted=true;
    }
    ui->phasePlot->setInteractions(QCP::iRangeZoom | QCP::iSelectAxes |
                                      QCP::iSelectPlottables);
    ui->phasePlot->graph(0)->setSelectable(QCP::stSingleData);



    //Plot the frequency of Bodeplot
    //if (magnitudeplotted = false)
    {

    }
    ui->magnitudePlot->setInteractions(QCP::iRangeZoom | QCP::iSelectAxes |
                                      QCP::iSelectPlottables);
    ui->magnitudePlot->graph(0)->setSelectable(QCP::stSingleData);

}

void ControlSystemWindow::updateTfLabel(std::string numString, std::string denomString)
{
    ui->tfLabel->setText(QString::fromStdString(numString + " / " + denomString));
}

ControlSystemWindow::~ControlSystemWindow()
{
    delete ui;
}






















