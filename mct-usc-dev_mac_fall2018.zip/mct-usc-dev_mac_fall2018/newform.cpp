#include "newform.h"
#include "ui_newform.h"

newform::newform(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::newform)
{
    ui->setupUi(this);
}

newform::~newform()
{
    delete ui;
}
