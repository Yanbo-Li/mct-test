#include "mousedrag.h"

MouseDrag::MouseDrag()
{

}
