#ifndef NEWFORM_H
#define NEWFORM_H

#include <QWidget>

namespace Ui {
class newform;
}

class newform : public QWidget
{
    Q_OBJECT

public:
    explicit newform(QWidget *parent = 0);
    ~newform();

private:
    Ui::newform *ui;
};

#endif // NEWFORM_H
