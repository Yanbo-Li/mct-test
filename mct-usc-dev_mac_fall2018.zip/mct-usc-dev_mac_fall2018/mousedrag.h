#ifndef MOUSEDRAG_H
#define MOUSEDRAG_H


class MouseDrag
{
public:
    MouseDrag();
};

#endif // MOUSEDRAG_H